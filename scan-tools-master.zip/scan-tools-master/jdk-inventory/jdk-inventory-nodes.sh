#!/bin/sh

NODES_PRD=jdk-inventory-prd.nodes
NODES_NONPRD=jdk-inventory-nonprd.nodes
rm -f $NODES_NONPRD $NODES_PRD

DIR=/tmp/rundeck-nodes
RUNDECK_REPO=git@github.wsgc.com:eCommerce-DevOps/toolchain-resource-model.git

rm -rf $DIR
git clone --depth 1 git@github.wsgc.com:eCommerce-DevOps/toolchain-resource-model.git $DIR

for group in $(find $DIR -name resources.xml | grep -i prd | egrep -iv "nonprd")
do
    #echo "prd group: $group"
    for node in $(grep -i "node name" $group | awk -F "node name=" '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g -es/\'//g )
    do
        echo "$node" >> $NODES_PRD.new
    done
done

for group in $(find $DIR -name resources.xml)
do
    #echo "nonprd group: $group"
    for node in $(grep -i "node name" $group | awk -F "node name=" '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g -es/\'//g )
    do
        [[ $node =~ -prd ]] && continue
        [[ $node =~ prdrk ]] && continue
        [[ $node =~ prdab ]] && continue
        [[ $node =~ prdsac ]] && continue
        [[ $node =~ preprd ]] && continue
        [[ $node =~ caprd ]] && continue
        echo "$node" >> $NODES_NONPRD.new
    done
done

sort -u $NODES_NONPRD.new > $NODES_NONPRD && rm $NODES_NONPRD.new
sort -u $NODES_PRD.new > $NODES_PRD && rm $NODES_PRD.new 

git add $NODES_PRD $NODES_NONPRD
git commit -m "Updated node lists" $NODES_PRD $NODES_NONPRD
git push

