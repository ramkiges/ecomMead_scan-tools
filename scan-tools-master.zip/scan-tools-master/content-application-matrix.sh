#!/bin/sh
PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin:/apps/mead-tools:/apps:/apps/scripts/env_summary:~/bin
TMP=/tmp/$(basename $0 | sed -es/\.sh//g)-$LOGNAME

CSV() { echo "$*" >> $CSV_DATA.new; }
HTML() { echo "$*" >> $OUTFILE; }
BailOut() { [ -n "$1" ] && echo "$*"; exit 1; }

DNS_HOSTS="ecmrck-vicn ecmsac-vicn bgbrck-vicn bgbsac-vicn wcmsac-vicn wcmrck-vicn aemrck-vdcn aemsac-vicn aemash-vicn imgsac-vicn imgrck-vicn"
RUNDECK_SHOW=https://rundeck.wsgc.com/rundeck/project/wsgc/job/show
RUNDECK_JOBS=https://rundeck.wsgc.com/rundeck/project/wsgc/jobs

KUBE_CLUSTER=ucp_container-api01.nonprod.wsgc.com
KUBE_CONFIG=$HOME/.kube/$KUBE_CLUSTER/config

SCAN_REPO=git@github.wsgc.com:eCommerce-Mead/scan-tools.git
[[ -e $TMP/scan-tools/.git ]] || git clone --depth 1 -q $SCAN_REPO $TMP/scan-tools
cd $TMP/scan-tools;git pull
INVENTORY=$TMP/scan-tools/Ecom_Server_Inventory.csv
CSV_DATA=$TMP/scan-tools/content-info.csv
rm -f $CSV_DATA.new
echo $CSV_DATA.new
CSV "# App, Market, Environment, Brand"

PROLOGUE="$(basename $0 | sed -es/\.sh//g)-prologue.html"

RUNDECK_REPO=git@github.wsgc.com:eCommerce-DevOps/toolchain-resource-model.git
[[ -e $TMP/rundeck/.git ]] || git clone --depth 1 -q $RUNDECK_REPO $TMP/rundeck
cd $TMP/rundeck;git pull

APP_LIST="\
ecmagent-svc \
ecmagent-bgb \
ecmagent-imgproc \
ecmauth \
ecmpub \
bgb-service \
buildsystem \
wcm-cq \
frontend \
xcadm \
contentprocessor \
edam \
aes \
ws-recipe \
cma-service \
"
# pulled this out for now
#ecmpreview \

# status colors
STATUS_DNS="#80aaff"
STATUS_MIA="#ccccff"
STATUS_CFG="#e699ff"
STATUS_PKG="#cccc00"

[ -n "$1" ] && APP_LIST="$*"

# confluence settings
DOC_SPACE="ES"
CCLIDIR="/apps/scripts/atlassian-cli-3.2.0"
PAGENAME="Content Application Environment Matrix"
OUTFILE="$TMP/$(basename $0 | sed -es/\.sh//g).html"
rm -f $OUTFILE
echo $OUTFILE

# ssh props
#SSH_KEY=/home/rundeck/.ssh/id_rsa
SSH_USER=imageuser
SSH_KEY=~/.ssh/id_rsa
echo "$LOGNAME" | grep -iq "a_" && SSH_USER=$LOGNAME


getPkg() {
      target=$1

      /bin/timeout -k 30s 10s ssh -o StrictHostKeyChecking=no -q -i $SSH_KEY $SSH_USER@$target \
        "rpm -qa |grep -i 'wsgc' | grep -i 'config' | egrep -v 'grep|httpd' | sed -es/\.noarch//g | awk -F_ '{ print \$1 }' "
}

HTML "<!-- $(date) -->"
HTML "$(cat $TMP/scan-tools/$PROLOGUE)"

HTML "<h5>This page is <font color='red'><a href='https://rundeck.wsgc.com/rundeck/project/wsgc/job/show/generate-content-application-matrix'>dynamically generated</a></font> - any manual edits will be lost</h5>"

# legend for status colors
HTML "<table border='1'>"
HTML "  <tr><td bgcolor='$STATUS_DNS' align='center'><font size='-1'>Host not found in DNS</font></td></tr>"
HTML "  <tr><td bgcolor='$STATUS_MIA' align='center'><font size='-1'>Host not found in RunDeck</font></td></tr>"
HTML "  <tr><td bgcolor='$STATUS_CFG' align='center'><font size='-1'>No config package found</font></td></tr>"
HTML "  <tr><td bgcolor='$STATUS_PKG' align='center'><font size='-1'>No packages installed</font></td></tr>"
HTML "</table>"
HTML

for app in $APP_LIST
do
  ENV_COUNT=0
  echo "*** $app ***"
  readme=
  # default env list
  ENV_LIST="qa uat dev"

  brand=$(echo $app | awk -F- '{ print $2 }')
  label=$(echo "$app" | tr "a-z" "A-Z")
  [[ $app = "ecommerce-assortment-export" || $app = "aes" ]] && label="Assortment Export Service"
  [[ $app = "xcadm" ]] && label="AdminTool"
  [[ $app = "ecmpreview" ]] && label="ECM Preview"
  [[ $app = "frontend" ]] && label="DP"
  [[ $app = "wcm-cq" ]] && label="WCM"
  [[ $app = "ws-recipe" ]] && label="WS Recipe"
  [[ $app = "cma-service" ]] && label="CMA"
  [[ $app = "bgb-service" ]] && label="BGB Service (standalone)"
  [[ $app = "ecmagent-svc" ]] && label="ECM Agent Service (aka Pub Agent)"
  [[ $app = "ecmagent-bgb" ]] && label="ECM Agent BGB"
  [[ $app = "ecmagent-imgproc" ]] && label="ECM Agent Image Processor"
  [[ $app = "ecmauth" ]] && label="ECM Author"
  [[ $app = "ecmpub" ]] && label="ECM Publish"
  [[ $app = "buildsystem" ]] && label="BuildSystem"
  [[ $app = "contentprocessor" ]] && label="Content Processor"
  echo "$app" | grep -qi "ecmprv" && label="ECM Preview $(echo $brand | tr 'a-z' 'A-Z')"

  [[ $app = "xcadm" ]] && ENV_LIST="qa-ca1 qa-ca3 qa-uat1"
  [[ $app = "ecmpreview" ]] && ENV_LIST=""
  [[ $app = "frontend" ]] && ENV_LIST="uat7-mg uat7-pb uat7-pk uat7-pt uat7-we uat7-ws cauat7-pb cauat7-pk cauat7-we cauat7-ws rgs2-mg rgs2-pb rgs2-pk rgs2-pt rgs2-we rgs2-ws qa5-mg qa5-pb qa5-pk qa5-pt qa5-we qa5-ws"
  [[ $app = "ws-recipe" ]] && ENV_LIST="qa uat"
  [[ $app = "cma-service" ]] && ENV_LIST="qa uat"
  [[ $app = "bgb-service" ]] && ENV_LIST="dev qa1 rgs1 uat1 ca-rgs1 uat2 ca-qa1 ca-uat1 ca1 prdrk ca-prdrk"
  [[ $app = "buildsystem" ]] && ENV_LIST="dev qa1 rgs1 uat1 ca-rgs1 uat2 prdrk ca-prdrk"
  [[ $app = "ecmauth" || $app = "ecmpub" ]] && ENV_LIST="ca1 qa1 uat1 rgs perf prdrk"
  [[ $app = "wcm-cq" ]] && ENV_LIST="ca1 qa1 qa2 qa4 qa5 rgs rgs2 rgs3 uat1 uat2 perf dev prd"
  [[ $app = "ecmagent-bgb" || $app = "ecmagent-svc" ]] && ENV_LIST="int uat1 qa1 qa2 qa3 rgs1 perf1 staging ca-uat1 ca-qa1 ca-qa2 ca-qa3 ca-rgs1 ca-perf1 ca-staging prdrk ca-prdrk"
  [[ $app = "ecmagent-imgproc" ]] && ENV_LIST="int uat1 rgs1 ca-qa1 ca-uat1 prdrk ca-prdrk"
  [[ $app = "contentprocessor" ]] && ENV_LIST="qa1 qa2 qa4 qa5 qa7 rgs rgs2 rgs3 uat1 uat2 ca1 dev perf prdrk"
  [[ $app = "edam" ]] && ENV_LIST="dev uat qa prd performance regression"
  #[[ $app = "ecommerce-assortment-export" || $app = "aes" ]] && ENV_LIST="qa1 qa2 perf uat ca1 rgs rgs2 rgs3"
  [[ $app = "ecommerce-assortment-export" || $app = "aes" ]] && ENV_LIST=$(cat /apps/rundeck-json/wcm/wcm-environmentlist-*.json | sed "s/[^[:alnum:]\.\-]//g")
  echo "$app" | grep -qi "ecmprv.*" && ENV_LIST="qa1 uat1 ca1"

  HTML "  <h4>$label</h4>"
  HTML "<table border='1' cellpadding='5' width='100%'>"
  HTML "  <tr>"
  HTML "      <th style='width:5%;text-align:center;'>Environment</th>"
  HTML "      <th style='width:15%;text-align:center;'>Repo</th>"
  HTML "      <th style='width:20%;text-align:center;'>RunDeck<br>Jenkins</br></th>"
  HTML "      <th style='width:40%;text-align:center;'>Host(s)</th>"
  HTML "      <th style='width:20%;text-align:center;'>Notes</th>"
  HTML "  </tr>"

  for env in $ENV_LIST
  do
    ENV_COUNT=$(expr $ENV_COUNT + 1)
    echo "+++ $app -> $env +++"
    repo=
    DEPLOY_JENKINS=
    DEPLOY_RUNDECK=

    case $app in 
      ecommerce-assortment-export | aes )
            #https://ecommerce-assortment-export-we-rgs2.services.west.nonprod.wsgc.com/summary
            BASE=https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/
            repo=$BASE
      ;;

      xcadm )
            BASE="https://repos.wsgc.com/svn/devops/application/xcadm/"
            echo "$env" | egrep -iq "qa|ca" && repo=$BASE/qa/config/trunk/$env
            echo "$env" | egrep -iq "prd" && repo=$BASE/prd/config/trunk/$env
            readme=$(svn cat $repo/README.md 2>/dev/null)
            echo "$env" | grep -iq "prd" && DEPLOY_JENKINS= || DEPLOY_JENKINS="deploy-xcadm-$env"
            echo "$env" | grep -iq "prd" && DEPLOY_RUNDECK= || DEPLOY_RUNDECK="$RUNDECK_SHOW/wsgc-deploy-qa-xcadm-update"
      ;;

      frontend | ecmpreview )
            BASE="https://repos.wsgc.com/svn/devops/application/frontend-2.1/qa/config/app/trunk"
            cfg=$(echo $env | awk -F- '{ print $1 }')
            brand=$(echo $env | awk -F- '{ print $2 }')
            repo=$BASE/$brand/$cfg
            readme=$(svn cat $repo/README.md 2>/dev/null)
      ;;

      ecmprv-* ) BASE="https://repos.wsgc.com/svn/devops/application/frontend-2.1/qa/config/app/trunk"
            brand=$(echo $app | awk -F- '{ print $2 }')
            repo=$BASE/$brand/ecm$env
            svn cat $repo/pom.xml >/dev/null 2>&1 || repo=
            readme=$(svn cat $repo/README.md 2>/dev/null)
      ;;

      ws-recipe )
            service="aem-content-apps"
            # first try and find it in git
            BASE="https://github.wsgc.com/eCommerce-DevOps"
            repo=$BASE/$service-$env-config
            repo_ssh=$(echo $repo | sed -es%https://%%g -es%github.wsgc.com/%github.wsgc.com:%g)
            rm -rf $TMP/$app-$env
            git clone --depth 1 -q git@$repo_ssh $TMP/$app-$env >/dev/null 2>&1 || repo=
            readme=$(cat $TMP/$app-$env/README.md 2>/dev/null)
      ;;

      cma | cma-service )
            service="cma"
            # first try and find it in git
            BASE="https://github.wsgc.com/eCommerce-DevOps"
            repo=$BASE/$service-$env-config
            repo_ssh=$(echo $repo | sed -es%https://%%g -es%github.wsgc.com/%github.wsgc.com:%g)
            rm -rf $TMP/$app-$env
            git clone --depth 1 -q git@$repo_ssh $TMP/$app-$env >/dev/null 2>&1 || repo=
            readme=$(cat $TMP/$app-$env/README.md 2>/dev/null)
      ;;

      bgb-service | bgb ) 
            service=bgb
            # first try and find it in git
            BASE="https://github.wsgc.com/eCommerce-DevOps"
            repo=$BASE/$service-$env-config
            repo_ssh=$(echo $repo | sed -es%https://%%g -es%github.wsgc.com/%github.wsgc.com:%g)
            rm -rf $TMP/$app-$env
            git clone --depth 1 -q git@$repo_ssh $TMP/$app-$env >/dev/null 2>&1 || repo=
            readme=$(cat $TMP/$app-$env/README.md 2>/dev/null)

            if  [[ -z $repo ]]
            then
              BASE="https://repos.wsgc.com/svn/devops/toolchain/bgb" 
              repo=$BASE/$env/config/bgb/trunk
              svn cat $repo/pom.xml >/dev/null 2>&1 || repo=
              readme=$(svn cat $repo/README.md 2>/dev/null)
            fi

            echo "$env" | grep -iq "prd" && DEPLOY_RUNDECK= || DEPLOY_RUNDECK=$RUNDECK_SHOW/wsgc-deploy-bgb-nonprd
            echo "$env" | grep -iq "prd" && DEPLOY_JENKINS= || DEPLOY_JENKINS=deploy-bgb-nonprd
            echo "$env" | grep -iq "ca-prd" && DEPLOY_RUNDECK=$RUNDECK_SHOW/wsgc-deploy-bgb-ca-prd-update 

            # for the time being there isn't a deployer for uat1
            [[ $env = "uat1" ]] && { DEPLOY_JENKINS=''; DEPLOY_RUNDECK=''; }
      ;;

      buildsystem ) 
            # first try and find it in git
            BASE="https://github.wsgc.com/eCommerce-DevOps"
            repo=$BASE/$app-$env-config
            repo_ssh=$(echo $repo | sed -es%https://%%g -es%github.wsgc.com/%github.wsgc.com:%g)
            rm -rf $TMP/$app-$env
            git clone --depth 1 -q git@$repo_ssh $TMP/$app-$env >/dev/null 2>&1 || repo=
            readme=$(cat $TMP/$app-$env/README.md 2>/dev/null)

            if [[ -z $repo ]]
            then
              BASE="https://repos.wsgc.com/svn/devops/toolchain/bgb" 
              repo=$BASE/$env/config/buildsystem/trunk
              svn cat $repo/pom.xml >/dev/null 2>&1 || repo=
              readme=$(svn cat $repo/README.md 2>/dev/null)
            fi

            echo "$env" | grep -iq "prd" && DEPLOY_RUNDECK= || DEPLOY_RUNDECK="$RUNDECK_SHOW/deploy-buildsystem-nonprd"
            echo "$env" | grep -iq "prd" && DEPLOY_JENKINS= || DEPLOY_JENKINS="deploy-buildsystem-nonprd"
            echo "$env" | grep -iq "ca-prd" && DEPLOY_RUNDECK=$RUNDECK_SHOW/wsgc-deploy-buildsystem-ca-prd-update 

            # for the time being there isn't a deployer for uat1
            [[ $env = "uat1" ]] && { DEPLOY_JENKINS=''; DEPLOY_RUNDECK=''; }
      ;;

      contentprocessor ) BASE="https://repos.wsgc.com/svn/devops/application/contentprocessor"
            repo=$BASE/$env/config/cp/trunk/
            svn cat $repo/pom.xml >/dev/null 2>&1 || repo=
            readme=$(svn cat $repo/README.md 2>/dev/null)
            echo "$env" | grep -iq "prd" && DEPLOY_RUNDECK= || DEPLOY_RUNDECK="$RUNDECK_SHOW/wsgc-deploy-contentprocessor-nonprd"
            echo "$env" | grep -iq "prd" && DEPLOY_JENKINS= || DEPLOY_JENKINS="deploy-contentprocessor-nonprod"
      ;;

      ecmauth | ecmpub ) BASE="https://github.wsgc.com/eCommerce-DevOps"
            service=ecm
            repo=$BASE/$service-$env-config
            repo_ssh=$(echo $repo | sed -es%https://%%g -es%github.wsgc.com/%github.wsgc.com:%g)
            rm -rf $TMP/$service-$env
            git clone --depth 1 -q git@$repo_ssh $TMP/$service-$env || { repo=; echo "$repo_ssh not found"; }
            readme=$(cat $TMP/$service-$env/README.md 2>/dev/null)
            echo "$env" | grep -iq "prd" && DEPLOY_RUNDECK=$RUNDECK_JOBS/deploy/prd/prdrk/ecm || DEPLOY_RUNDECK="$RUNDECK_SHOW/wsgc-deploy-ecm-nonprd"
            echo "$env" | grep -iq "prd" && DEPLOY_JENKINS= || DEPLOY_JENKINS="deploy-ecm-nonprd"
      ;;

      ecmagent-imgproc ) BASE="https://github.wsgc.com/eCommerce-DevOps"
            repo=$BASE/$app-$env-config
            repo_ssh=$(echo $repo | sed -es%https://%%g -es%github.wsgc.com/%github.wsgc.com:%g)
            readme=$(svn cat $repo/README.md 2>/dev/null)
            rm -rf $TMP/$app-$env
            git clone --depth 1 -q git@$repo_ssh $TMP/$app-$env || { repo=; echo "$repo_ssh not found"; }
            readme=$(cat $TMP/$app-$env/README.md 2>/dev/null)
            echo "$env" | grep -iq "prd" && DEPLOY_RUNDECK=$RUNDECK_JOBS/deploy/prd/prdrk/ecmagent || DEPLOY_RUNDECK="$RUNDECK_SHOW/wsgc-deploy-ecmagent-imgproc-nonprd"
            echo "$env" | grep -iq "ca-prd" && DEPLOY_RUNDECK=$RUNDECK_JOBS/deploy/prd/caprdrk/ecmagent 
            echo "$env" | grep -iq "prd" && DEPLOY_JENKINS= || DEPLOY_JENKINS="deploy-ecmagent-imgproc-nonprd"

            # there is not a deployer for the "int" instance, and there never will be
            echo "$env" | grep -iq "int" && { DEPLOY_JENKINS=; DEPLOY_RUNDECK="None - manually-deployed"; }
      ;;

      ecmagent-svc ) BASE="https://github.wsgc.com/eCommerce-DevOps"
            service=ecmagent-service
            repo=$BASE/$service-$env-config
            repo_ssh=$(echo $repo | sed -es%https://%%g -es%github.wsgc.com/%github.wsgc.com:%g)
            rm -rf $TMP/$service-$env
            git clone --depth 1 -q git@$repo_ssh $TMP/$service-$env || { repo=; echo "$repo_ssh not found"; }
            readme=$(cat $TMP/$service-$env/README.md 2>/dev/null)
            echo "$env" | grep -iq "prd" && DEPLOY_RUNDECK=$RUNDECK_JOBS/deploy/prd/prdrk/ecmagent || DEPLOY_RUNDECK="$RUNDECK_SHOW/wsgc-deploy-ecmagent-nonprd"
            echo "$env" | grep -iq "ca-prd" && DEPLOY_RUNDECK=$RUNDECK_JOBS/deploy/prd/caprdrk/ecmagent 
            echo "$env" | grep -iq "prd" && DEPLOY_JENKINS= || DEPLOY_JENKINS="deploy-ecmagent-svc-nonprd"

            # there is not a deployer for the "int" instance, and there never will be
            echo "$env" | grep -iq "int" && { DEPLOY_JENKINS=; DEPLOY_RUNDECK="None - manually-deployed"; }
      ;;

      ecmagent-bgb ) BASE="https://github.wsgc.com/eCommerce-DevOps"
            repo=$BASE/$app-$env-config
            repo_ssh=$(echo $repo | sed -es%https://%%g -es%github.wsgc.com/%github.wsgc.com:%g)
            rm -rf $TMP/$app-$env
            git clone --depth 1 -q git@$repo_ssh $TMP/$app-$env 2>/dev/null || { repo=; echo "$repo_ssh not found"; }
            readme=$(cat $TMP/$app-$env/README.md 2>/dev/null)

            if  [[ -z $repo ]]
            then
              BASE="https://repos.wsgc.com/svn/devops/toolchain/bgb" 
              repo=$BASE/$env/config/bgb/trunk
              svn cat $repo/pom.xml >/dev/null 2>&1 || repo=
              readme=$(svn cat $repo/README.md 2>/dev/null)
            fi

            echo "$env" | grep -iq "prd" && DEPLOY_RUNDECK=$RUNDECK_JOBS/deploy/prd/prdrk/ecmagent || DEPLOY_RUNDECK="$RUNDECK_SHOW/wsgc-deploy-ecmagent-bgb-nonprd"
            echo "$env" | grep -iq "ca-prd" && DEPLOY_RUNDECK=$RUNDECK_JOBS/deploy/prd/caprdrk/ecmagent || DEPLOY_RUNDECK="$RUNDECK_SHOW/wsgc-deploy-ecmagent-bgb-nonprd"
            echo "$env" | grep -iq "prd" && DEPLOY_JENKINS= || DEPLOY_JENKINS="deploy-ecmagent-bgb-nonprd"

            # there is not a deployer for the "int" instance, and there never will be
            echo "$env" | grep -iq "int" && { DEPLOY_JENKINS=; DEPLOY_RUNDECK=; }
      ;;

      wcm-cq ) BASE="https://github.wsgc.com/eCommerce-DevOps"
            service=wcm
            repo=$BASE/$service-$env-config
            repo_ssh=$(echo $repo | sed -es%https://%%g -es%github.wsgc.com/%github.wsgc.com:%g)
            rm -rf $TMP/$service-$env
            git clone --depth 1 -q git@$repo_ssh $TMP/$service-$env || { repo=; echo "$repo_ssh not found"; }
            readme=$(cat $TMP/$service-$env/README.md 2>/dev/null)
            echo "$env" | grep -iq "prd" && DEPLOY_RUNDECK=$RUNDECK_JOBS/deploy/prd/prdrk/wcm || DEPLOY_RUNDECK="$RUNDECK_SHOW/wsgc-deploy-wcm-nonprd-any"
            echo "$env" | grep -iq "prd" && DEPLOY_JENKINS= || DEPLOY_JENKINS="deploy-wcm-nonprd-any"
      ;;

      edam ) BASE="https://github.wsgc.com/eCommerce-DevOps"
            repo=$BASE/$app-$env-config
            repo_ssh=$(echo $repo | sed -es%https://%%g -es%github.wsgc.com/%github.wsgc.com:%g)
            rm -rf $TMP/$app-$env
            git clone --depth 1 -q git@$repo_ssh $TMP/$app-$env || { repo=; echo "$repo_ssh not found"; }
            readme=$(cat $TMP/$app-$env/README.md 2>/dev/null)
            echo "$env" | grep -iq "prd" && DEPLOY_RUNDECK=$RUNDECK_JOBS || DEPLOY_RUNDECK="$RUNDECK_SHOW/"
            echo "$env" | grep -iq "prd" && DEPLOY_JENKINS= || DEPLOY_JENKINS=""
      ;;

        * ) echo "No base for $app"; continue ;;
    esac

    [[ -n $1 ]] && echo "repo: $repo"

    host=$(grep -ir "tags=.*$app" $TMP/rundeck | egrep -i "tags=.*,$env\b" | awk -F 'node name=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g)
    [[ $app = "wcm-cq" ]] && host=$(grep -ir "tags=.*wcm" $TMP/rundeck | egrep -i "tags=.*,$env\b" | grep -iv contentprocessor | awk -F 'node name=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g)
    [[ $app = "aes" ]] && host=$(cat /apps/rundeck-json/wcm/*/aes-serverlist-$env-*.json | egrep -iv "#" | sed "s/[^[:alnum:]\.\-]//g")

    display_repo=$(echo $repo | sed -es%https://github.wsgc.com/eCommerce-DevOps/%%g -es%https://repos.wsgc.com/svn/devops/%%g -es%/trunk%%g)
    [[ -n $DEPLOY_JENKINS ]] && display_jenkins=https://ecombuild.wsgc.com/jenkins/job/$DEPLOY_JENKINS/ || display_jenkins=
    [[ -n $DEPLOY_RUNDECK ]] && display_rundeck=$DEPLOY_RUNDECK || display_rundeck=
    display_rundeck=$(echo "$display_rundeck" | sed -es%"$RUNDECK_SHOW/"%%g -es%"$RUNDECK_JOBS/"%%g)

    # snowflakes
    [[ $host = "ecmagentintrk1v" ]] && readme="Legacy host - needs to be decomm'd - replaced by ecmagent-uat1-rk1v (aka ecmagent-int-rk1v)"

    BGCOLOR=
    [[ -z $repo ]] && BGCOLOR=$STATUS_CFG
    #echo "$app:$env:$host:$repo"    
    HTML "<tr>"
    HTML "  <td>$env</td>"
    HTML "  <td bgcolor='$BGCOLOR'><a href='$repo'>$display_repo</a></td>"
    HTML "  <td>"
    HTML "    <a href='$DEPLOY_RUNDECK'>$display_rundeck</a><br>"
    HTML "    <a href='$display_jenkins'>$DEPLOY_JENKINS</a></br>"
    HTML "    </td>"
    HTML "  <td>"

    #hc=$(echo "$host" | xargs -n1 | sort -u | egrep -iv "^$" | wc -l)
    #echo "host: [$host] ($hc)"
    br=
    HTML "<table border='0' width='100%'>"

    HTML "  <style> .wiki-content .confluenceTh, .wiki-content .confluenceTd { border: none; } </style>"

    [[ -z $host ]] && HTML "<td bgcolor='$STATUS_MIA'>&nbsp;</td>"

    for h in $host
    do
      b=
      BGCOLOR=
      endpoint=
      proto="http://"
      pkg=

      ip=$(host $h 2>/dev/null | grep -i address | awk '{ print $NF }')
      if [[ -n $ip ]]
      then
        if [[ $app = "aes" ]]
        then
          #hack
          echo "$h" | grep -iq "mg" && b=mg 
          echo "$h" | grep -iq "pb" && b=pb 
          echo "$h" | grep -iq "pk" && b=pk 
          echo "$h" | grep -iq "pt" && b=pt 
          echo "$h" | grep -iq "we" && b=we 
          echo "$h" | grep -iq "ws" && b=ws 
          display_repo=$BASE/assortment-export-$b-k8s-package
          #endpoint=$h/summary
          pkg=$app
        fi
        h=$(echo $h | awk -F\. '{ print $1 }')
        ugly=$(host $h 2>/dev/null | grep -i alias | awk '{ print $NF }' | awk -F\. '{ print $1 }')
        [[ -z $pkg ]] && pkg=$(getPkg $h)
        [[ -z $pkg && -n $ugly ]] && pkg=$(getPkg $ugly)
        [[ -z $endpoint ]] && endpoint=$(egrep -i "$h" $INVENTORY | grep -i "$app" | awk -F, '{ print $5 }')
        echo "$endpoint" | egrep -iq "443" && proto="https://"
        [[ -z $endpoint && -n $ugly ]] && endpoint=$(egrep -i "$ugly" $INVENTORY | grep -i "$app"| awk -F, '{ print $5 }')
        #h="$h.wsgc.com"
        [[ -n $1 ]] && echo "endpoint $app: $proto$h$endpoint"
        [[ -z $pkg ]] && BGCOLOR=$STATUS_PKG
      else
        endpoint=
        pkg=
        ugly=$h
        BGCOLOR=$STATUS_DNS 
      fi

      echo "$app" | egrep -iq "ecmauth|ecmpub|wcm-cq" && b=$(echo $h | awk -F- '{ print $1 }')

      CSV "$app,$market,$env,$b,$h,$ugly,$display_repo,$display_jenkins,$DEPLOY_RUNDECK,${proto}${h}.wsgc.com${endpoint}"

      HTML "<tr>"
      #HTML "${br}<a href='' title='$ugly'>${h} ${pkg}"
      HTML "<td style='width:30%' bgcolor='$BGCOLOR'><a href='${proto}${h}.wsgc.com${endpoint}' title='$ugly'>${h}</a></td><td style='width:70%' bgcolor='$BGCOLOR'>${pkg}</td>"
      HTML "</tr>"

      br="<br/>" 
    done
    HTML "</table>"

    #echo "$readme" | egrep -iq "mead-|tah-|whitney-|kabru-" && readme=
    #[[ -n $1 ]] && echo "readme: $readme"
    HTML "<td>$readme&nbsp;</td>" 

    HTML "</td>"
    HTML "</tr>"
    rm -rf $TMP/$app-$env
  done
  echo "ENV_COUNT: $ENV_COUNT"
  HTML "</table>"
done

HTML "<p>Generated by <i>$LOGNAME</i></p>"

if [[ -z $1 ]]
then 
  echo "=== Update confluence $PAGENAME ==="

  # add scan-provisioned-host output
  cd $TMP/scan-tools
  sh scan-provisioned-hosts $DNS_HOSTS > $TMP/scan-provisioned-hosts.txt
  HTML "<pre>$(cat  $TMP/scan-provisioned-hosts.txt)</pre>"

  # update confluence
  sh $CCLIDIR/confluence.sh --space "$DOC_SPACE" --title "$PAGENAME" --action storepage --file $OUTFILE --noConvert --verbose || echo "Confluence update failed"

  # commit CSV file
  mv $CSV_DATA.new $CSV_DATA
  git pull
  git add $CSV_DATA
  git commit $CSV_DATA -m "Update"
  git push
else
  echo "=== Skipping confluence and git updates ==="
fi

exit 0

