[Ecom_Server_Inventory_v5.csv	]

This file is to maintain the Ecom Non Prod server inventory list with Server,Application,Environment,EndpointURL,ServiceName

[app-scan.sh]

This is the main script which will be monitoring and running through rundeck 

