#!/bin/bash
# https://github.wsgc.com/eCommerce-Mead/scan-tools/tree/master/app-scan
PATH=/apps/mead-tools:/apps:/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin
export PATH

renice -n +20 $$

Usage() {
    echo "Usage: $(basename $0) [service]"
}

# error-and-exit function
BailOut() {
    [ -n "$1" ] && echo "$*"

    Usage
    rm -rf $TMP
    exit 1
}

# Common Variables
PROD_HOSTS="vpcn|vccn|-prd-|prdab|prdsac|prdrk"
TMP=/tmp/$(basename $0 | sed -es/\.sh//g)
NOTIFICATIONS=$TMP-notifications
TMP=$TMP-$$
INPUT_CSV=$TMP/Ecom_Server_Inventory.csv
MAILFILE=$TMP/mailfile.txt
TODAY=$(date +'%Y-%m-%d')

# Jira defaults
JIRA_TITLE="AppScan"
JIRA_TEAM=MEAD
JIRA_LABEL="Proactive-Monitoring"
JIRA_URL="https://jira.wsgc.com"


JIRA_LOG=$TMP/app-scan/$(basename $0 | sed -es/\.sh//g)-jira-log.csv
# history file
HISTORY=$TMP/app-scan/$(basename $0 | sed -es/\.sh//g)-history.csv
# status tracking file for systems with chronic problems
PROBLEM_FILE=$TMP/app-scan/$(basename $0 | sed -es/\.sh//g)-problems.csv
TICKET_FILE=$TMP/app-scan/$(basename $0 | sed -es/\.sh//g)-tickets.csv
RESTART_FILE=$TMP/app-scan/$(basename $0 | sed -es/\.sh//g)-restarts.csv
CERTS_FILE=$TMP/$(basename $0 | sed -es/\.sh//g)-certs.csv
CERT_DAYS=31
PROBLEM_THRESH=2
RESTART_THRESH=2
# how many days worth of history to keep
HISTORY_DAYS=10
# restart count window
RESTART_DAYS=2

GIT_USER=$(grep "email.*=" ~/.gitconfig | awk '{ print $NF }')
GIT_REPO=git@github.wsgc.com:eCommerce-Mead/scan-tools.git
emailAddress=ecomMead@wsgc.com
#emailAddress=tfitzpatrick@wsgc.com
SUBJECT="NonProd Service Health"

# curl options
TIMEOUT="--retry 2 --connect-timeout 30 --max-time 60"
USER_AGENT="--user-agent AppScan:ProactiveMonitoring"

RUNDECK_REPO=git@github.wsgc.com:eCommerce-DevOps/toolchain-resource-model.git

# initialize counters
JIRA_COUNT=0
JIRA_OPENED=0
JIRA_CLOSED=0
EMAIL_COUNT=0
ISSUE_COUNT=0
RESTART_INIT_COUNT=0
SERVICE_COUNT=0
SERVER_COUNT=0
TICKET_COUNT=0
DECOM_COUNT=0

# number of seconds to wait for service to start
[ -z "$SERVICE_WAIT" ] && SERVICE_WAIT=0
umask 000

# emoticons
RUNDECK_MISSING="<ac:emoticon ac:name='warning'/>"
RESTART_INIT="<ac:emoticon ac:name='information'/>"
RESTART_FORBIDDEN="<ac:emoticon ac:name='minus'/>"
RESTART_CONFLICT="<ac:emoticon ac:name='cross'/>"
TICKET_CREATED="<ac:emoticon ac:name='yellow-star'/>"

RESTART_FORBIDDEN_COUNT=0
RESTART_CONFLICT_COUNT=0
RESTART_INIT_COUNT=0
RUNDECK_MISSING_COUNT=0

DNS_FAIL_COUNT=0
PING_FAIL_COUNT=0
UNMONITORED_COUNT=0

# create TMP directory
rm -rf $TMP 
mkdir -p $TMP || BailOut "Unable to create $TMP"

# Implement Input csv fetch from scm
echo "*** Checkout $GIT_REPO"
git clone --depth 1 --quiet $GIT_REPO $TMP || BailOut "Unable to clone $GIT_REPO as $GIT_USER"
cd $TMP
git checkout master

# checkout RunDeck repo
echo "*** Checkout $RUNDECK_REPO"
git clone --depth 1 --quiet $RUNDECK_REPO $TMP/rundeck || BailOut "Unable to clone $RUNDECK_REPO as $GIT_USER"

# confluence settings
DOC_SPACE="ES"
CCLIDIR="/apps/scripts/atlassian-cli-3.2.0"
PAGENAME="NonProd Service Health"
OUTFILE=$TMP/status.html
rm -f $OUTFILE

# certs file
[ -z "$KEYWORD" ] && rm -f $CERTS_FILE.new

# status colors
STATUS_PG="#cc00cc"
STATUS_DN="#ff6666"
STATUS_UP="#33cc00"
STATUS_NA="#cccc00"
STATUS_DNS="#80aaff"
STATUS_UM="#ffffcc"
STATUS_DECOM="#c2c2a3" 

# ssh props
SSH_KEY=/home/rundeck/.ssh/id_rsa
SSH_USER=imageuser

HTML() {
    echo "$*" >> $OUTFILE
}

testDNS() {
    echo ">>> $FUNCNAME $Server"
    #Hostname=$(host $Server >/dev/null 2>&1)
    Hostname=$(host $Server)
    return $?
}

testPing() {
    #echo ">>> $FUNCNAME $Server"
    ping -c 2 $Server >/dev/null 2>&1
    return $?
}

serviceTest() {
    ret=255
    OPTIONS="-L -X GET"
    echo ">>> $FUNCNAME $Server $ServiceName"

    if [ -f "$TMP/$ServiceName.cred" ]
    then
        . $TMP/$ServiceName.cred
        LOGIN="--user $user:$pass"
        OPTIONS=
    else
        LOGIN=        
    fi

    for try in 1 2 
    do
        # put this here so it will only trigger if we've already tested once
        [[ $RESTART = "true" && -n "$ret" ]] && serviceRestart

        for proto in http https 
        do
            testURL="$proto://${Server}.wsgc.com${EndPoint}"
            
            if echo "$proto" | grep -iq telnet
            then
                # if the endpoint is a URL then don't bother with telnet
                echo "$EndPoint" | grep -Eq "[[:alpha:]].*" && continue

                http_status=
                port=$(echo "$EndPoint" | sed -es/://g)
                /bin/timeout -k 10s 5s nc -w 5 $Server $port </dev/null >/dev/null 2>&1
                ret=$?
            fi

            if echo "$proto" | grep -iq http
            then
                http_status=$(curl $OPTIONS $LOGIN $TIMEOUT $USER_AGENT -o /dev/null --insecure --silent --head --write-out '%{http_code}\n' $testURL)
#echo "http_status: $http_status"
                case $http_status in 
                    200 ) ret=0 ;; # url worked
                    302 ) ret=0 ;; # url worked but redirected 
                    401 ) ret=0 ;; # url worked but wrong creds
                    403 ) ret=0 ;; # url worked but wrong creds
                    000 ) ret=255 ;; # connection aborted before it was completed
                    * ) ret=$http_status ;;
                esac
            fi
            # if the service is Ok, break out of the loop
            [[ $ret -eq 0 ]] && break
        done

        # if the service is Ok, break out of the loop
        [[ $ret -eq 0 ]] && break

        # if the restart flag isn't set, don't bother trying again
        [[ $RESTART = "true" ]] || break
    done
    [[ $ret -eq 0 ]] && EndPointURL="$testURL"
    [[ -z $ret ]] && ret=255

    echo "$EndPointURL $ret ($http_status)"
    return $ret
}

serviceRestart() {
    if [ "$RestartEnabled" != "y" ] 
    then
        echo "restart not enabled for $Server"
        FLAG=$RESTART_FORBIDDEN
        RESTART_FORBIDDEN_COUNT=$(expr $RESTART_FORBIDDEN_COUNT + 1)
        return 0
    fi
    FLAG=$RESTART_INIT

    echo ">>> $FUNCNAME $Server $ServiceName"

    # check to see if a deployment is in-progress
    DEPLOY=$(ssh -o StrictHostKeyChecking=no -tt -q -i $SSH_KEY $SSH_USER@$Server "/bin/ps -ef | /bin/egrep -i 'yum|rpm|rerun' | /bin/egrep -vi 'grep' ")
    if [ -n "$DEPLOY" ]
    then
        echo "@@@ Deployment appears to be in progress, skipping 
$DEPLOY"
        FLAG=$RESTART_CONFLICT
        RESTART_CONFLICT_COUNT=$(expr $RESTART_CONFLICT_COUNT + 1)
        return 0
    fi

    # restart service
    if [ -n "$ServiceName" ] 
    then
        # log the restart
        echo "$DATE,$Server,$ServiceName" >> $RESTART_FILE

        # update frontend
        if [ "$ServiceName" = "wsgc-tomcat-frontend" ]
        then
                echo "*** update packages for $ServiceName"
                /bin/timeout -k 30s 10s ssh -o StrictHostKeyChecking=no -tt -q -i $SSH_KEY $SSH_USER@$Server "sudo /usr/bin/yum -y --disablerepo=\* --enablerepo=wsgc-\* update wsgc-devops\* -d1"
        fi

        echo "*** restart $ServiceName"
        /bin/timeout -k 30s 10s ssh -o StrictHostKeyChecking=no -tt -q -i $SSH_KEY $SSH_USER@$Server "sudo /sbin/service $ServiceName restart </dev/null"

        [ $SERVICE_WAIT -gt 0 ] && { echo "%%% Waiting $SERVICE_WAIT seconds for service startup"; sleep $SERVICE_WAIT; }

        # get status
        if [ -n "$KEYWORD" ]
        then
            echo "=== $ServiceName status:"
            ssh -o StrictHostKeyChecking=no -tt -q -i $SSH_KEY $SSH_USER@$Server "sudo /sbin/service $ServiceName status </dev/null"
        fi
    fi

    echo "*** restart httpd"
    /bin/timeout -k 30s 10s ssh -o StrictHostKeyChecking=no -tt -q -i $SSH_KEY $SSH_USER@$Server "sudo /sbin/service httpd stop </dev/null" 
    /bin/timeout -k 30s 10s ssh -o StrictHostKeyChecking=no -tt -q -i $SSH_KEY $SSH_USER@$Server "sudo /sbin/service httpd start </dev/null" 

    if [ -n "$KEYWORD" ]
    then
        echo "=== httpd status:"
        ssh -o StrictHostKeyChecking=no -tt -q -i $SSH_KEY $SSH_USER@$Server "sudo /sbin/service httpd status </dev/null"

        echo "+++ RPM Packages:"
        ssh -o StrictHostKeyChecking=no -tt -q -i $SSH_KEY $SSH_USER@$Server "rpm -qa | grep -i wsgc | egrep -iv 'jdk' | sort"

        echo "+++ Services:"
        ssh -o StrictHostKeyChecking=no -tt -q -i $SSH_KEY $SSH_USER@$Server "/sbin/chkconfig --list 2>/dev/null | grep -i wsgc"
    fi

    RESTART_INIT_COUNT=$(expr $RESTART_INIT_COUNT + 1)
}

# update email *and* problems files
updateNotification() {
    echo ">>> $FUNCNAME - $*"
    MESSAGE="$*"
    ISSUE_COUNT=$(expr $ISSUE_COUNT + 1);

    # update list of problem child machines
    updateProblems "$MESSAGE"

    # set a status file and see if it exists
    STATUS_FILE=$NOTIFICATIONS/$Server.status
    [ -f "$STATUS_FILE" ] && return

cat >> $MAILFILE << EOF
<tr>
    <td>$Application</td>
    <td>$LOG_URL</td>
    <td>$EndPointURL</td>
    <td>$MESSAGE</td>
</tr>

EOF

    # keep track of recent notifications by creating a status file
    touch $STATUS_FILE
    EMAIL_COUNT=$(expr $EMAIL_COUNT + 1);
}

# experimental problem tracking
updateProblems() {
    message=$1
 
    if [ -n "$message" ]
    then
        # add to problem file
        echo "$DATE,$Server,$message" >> $PROBLEM_FILE
    else
        # remove from problem file
        if grep -iq $Server $PROBLEM_FILE $TICKET_FILE
        then
            #echo "Remove $Server ($ServiceName) from problem file"
            cat $PROBLEM_FILE | egrep -vi "$Server,$ServiceName " > $PROBLEM_FILE.new
            mv $PROBLEM_FILE.new $PROBLEM_FILE

            for ticket in $(grep -i "$Server.*$ServiceName" $TICKET_FILE | awk -F, '{ print $3 }' | sort -u)
            do
                echo "Close Jira: $JIRA_URL/browse/$ticket - $ServiceName"
                problem=$(grep $Server $TICKET_FILE | awk -F, '{ print $4 }' | sort -u)
                ticketClose $ticket "Problem appears to be resolved, auto-closing [$problem]"
            done
        fi
    fi
}

certificateNotification() {
    message=$1
    DATE=$(date +'%Y-%m-%d %H:%M')
    grep -qi "$Server.*certificate" $TICKET_FILE && return

    # AEM-based tickets go to SCNS
    PROJECT=$JIRA_TEAM
    [[ $Server =~ ecm ]] && PROJECT=SCNS
    [[ $Server =~ wcm ]] && PROJECT=SCNS
    [[ $Server =~ aem ]] && PROJECT=SCNS
    [[ $Server =~ aes ]] && PROJECT=SCNS
    TICKET=$(jira-create -p $PROJECT -l $JIRA_LABEL -s "$JIRA_TITLE: $Server - SSL Certificate Expiration" -d "$message")
    JIRA_OPENED=$(expr $JIRA_OPENED + 1) 
    echo "$DATE,$Server,$TICKET,$message" >> $TICKET_FILE
    echo "*** $message - Created Jira https://jira.wsgc.com/browse/$TICKET"

    echo "$DATE,$Server,$TICKET,open,certificate" >> $JIRA_LOG

    # hook to generate a new cert
    CERT_TMP=/tmp/appscan-cert
    rm -rf $CERT_TMP
set -x
    git clone -q --depth 1 git@github.wsgc.com:eCommerce-Mead/certs.git $CERT_TMP
    pushd $(pwd) >/dev/null
    cd $CERT_TMP 
    #./dp-cert $ENVIRO
    popd >/dev/null
{ set +x; } 2>/dev/null
    rm -rf $CERT_TMP
}

ticketClose() {
    ticket=$1
    comment=$2

    echo "*** Close https://jira.wsgc.com/browse/$TICKET - $comment"
    jira-close -t "$ticket" -c "$comment"
    if [[ $comment =~ Certificate ]]
    then 
      jira-label "$ticket" "ops:certificate"
    else
      jira-label "$ticket" "brfx:auto-healing"
    fi
    JIRA_CLOSED=$(expr $JIRA_CLOSED + 1)

    cat $TICKET_FILE | egrep -vi "$ticket" > $TICKET_FILE.new
    mv $TICKET_FILE.new $TICKET_FILE

    echo "$DATE,$Server,$TICKET,close," >> $JIRA_LOG

    git pull --rebase --autostash
    git add $TICKET_FILE $JIRA_LOG
    git commit -q -m "Close $ticket" $TICKET_FILE
    git push -q
}

# initialize confluence page
rm -f $OUTFILE

HTML "<!-- $(date) -->"
HTML
HTML "This page provides a list of VM-based applications and their respective states; there is not yet a k8s equivalent."
HTML "<h5>This page is <a href='https://ecombuild.wsgc.com/jenkins/job/app-scan-nonprd/'>dynamically generated</a> - any manual edits will be lost</h5>"
#HTML "<table border='1'>"
#HTML "  <tr><th><font size='-1'>Issues found</font></th><td><font size='-1'>@ISSUE_COUNT@</font></td></tr>"
#HTML "  <tr><th><font size='-1'>Actions taken</font></th><td><font size='-1'>@RESTART_INIT_COUNT@</font></td></tr>"
#HTML "</table>"
#HTML

# legend for status colors
HTML "<table border='1'>"
HTML "  <tr><th><font size='-1'>Servers</font></th><td><font size='-1'>@SERVER_COUNT@</font></td></tr>"
HTML "  <tr><th><font size='-1'>Applications</font></th><td><font size='-1'>@SERVICE_COUNT@</font></td></tr>"
HTML "  <tr><th><font size='-1'>New Jira Tickets Opened last run</font></th><td><font size='-1'>@JIRA_OPENED@</font></td></tr>"
HTML "  <tr><th><font size='-1'>Old Jira Tickets Closed last run</font></th><td><font size='-1'>@JIRA_CLOSED@</font></td></tr>"
HTML "  <tr><th><font size='-1'>Old Jira Tickets Pending</font></th><td><font size='-1'>@JIRA_COUNT@</font></td></tr>"
HTML "  <tr><td bgcolor='$STATUS_DN' align='center'><font size='-1'>Service Fail</font></td><td><font size='-1'>@ISSUE_COUNT@</font></td></tr>"
HTML "  <tr><td bgcolor='$STATUS_UM' align='center'><font size='-1'>Un-Monitored</font></td><td><font size='-1'>@UNMONITORED_COUNT@</font></td></tr>"
HTML "  <tr><td bgcolor='$STATUS_PG' align='center'><font size='-1'>Ping Fail</font></td><td><font size='-1'>@PING_FAIL_COUNT@</font></td></tr>"
HTML "  <tr><td bgcolor='$STATUS_DNS' align='center'><font size='-1'>DNS Fail</font></td><td><font size='-1'>@DNS_FAIL_COUNT@</font></td></tr>"
HTML "  <tr><td bgcolor='$STATUS_DECOM' align='center'><font size='-1'>Scheduled for DeCom</font></td><td><font size='-1'>@DECOM_COUNT@</font></td></tr>"
HTML "  <tr><td align='center'><font size='-1'>$RESTART_INIT Auto-Restart Initiated</font></td><td><font size='-1'>@RESTART_INIT_COUNT@</font></td></tr>"
HTML "  <tr><td align='center'><font size='-1'>$RESTART_FORBIDDEN Auto-Restart Disallowed</font></td><td><font size='-1'>@RESTART_FORBIDDEN_COUNT@</font></td></tr>"
HTML "  <tr><td align='center'><font size='-1'>$RESTART_CONFLICT Deployment/Restart Conflict</font></td><td><font size='-1'>@RESTART_CONFLICT_COUNT@</font></td></tr>"
HTML "  <tr><td align='center'><font size='-1'>$RUNDECK_MISSING Missing from RunDeck</font></td><td><font size='-1'>@RUNDECK_MISSING_COUNT@</font></td></tr>"
HTML "  <tr><td align='center'><font size='-1'>$TICKET_CREATED Jira Ticket</font></td><td><font size='-1'>@TICKET_COUNT@</font></td></tr>"
HTML "</table>"
HTML

# headers for data columns
HTML "<table border='1'>"
HTML "  <tr>"
HTML "      <th>Service</th>"
HTML "      <th>Environment</th>"
HTML "      <th>Server</th>"
HTML "      <th>Service</th>"
HTML "      <th>Endpoint</th>"
HTML "  </tr>"
HTML

# initialize email message
cat > $MAILFILE << EOF
From: $emailAddress
Subject: $SUBJECT
Content-Type: text/html

<p>
<a href=https://confluence.wsgc.com/display/ES/NonProd+Service+Health>NonProd Service Health</a>
<p>New issues found: <font color=red><b>@EMAIL_COUNT@</b></font><p>
<table border='1' cellpadding=5>
    <tr>
        <th>Service</th>
        <th>Server</th>
        <th>Endpoint</th>
        <th>Status</th>
    </tr>

EOF

# clean up notifications
[ -z "$NOTIFICATIONS" ] && BailOut "How did NOTIFICATIONS become empty?"
mkdir -p $NOTIFICATIONS || BailOut "Unable to create $NOTIFICATIONS"
chmod 777 $NOTIFICATIONS >/dev/null 2>&1

# clean out notification files 
find $NOTIFICATIONS -type f -mtime +1 -exec rm -f {} \; 2>/dev/null &

# clean up tmp directories from test/failed runs
find $(dirname $TMP) -type d -name "$(basename $0 | sed -es/\.sh//g)-[1-9]*" -mtime +1 -exec rm -rf {} \; 2>/dev/null &

# parse options
while getopts "k:hr" opt
do
    case ${opt} in
        h | help ) Usage 
            exit 0
        ;;
        k | keyword ) 
            KEYWORD=$OPTARG                              
        ;;
        r ) RESTART=true :;
    esac
done

[ "$RESTART" = "true" ] && MSG="enabled" || MSG="disabled"
HTML "Global App restart is $MSG"
echo "Global App restart is $MSG"

# create list of services to process, either from the command line or all the lines in the file
[ -f $INPUT_CSV ] || BailOut "Input CSV ($INPUT_CSV) not found "
if [ -n "$KEYWORD" ] 
then
    SERVICE_LIST=$(cat $INPUT_CSV | egrep -iv "^#" | grep -i ",.*$KEYWORD.*," | awk -F, '{ print $3 }' | sort -u)
else
    SERVICE_LIST=$(cat $INPUT_CSV | egrep -iv "^#" | awk -F, '{ print $3 }' | sort -u)
fi

HOST_LIST=$(echo "$HOST_LIST" | xargs -n1 | sort -u | tr '\n' ' ' | sed -es/','/' '/g -es'/^[ \t]*//;s/[ \t]*$//')
[[ -n $HOST_LIST ]] && echo "HOST_LIST:[$HOST_LIST]"

# main loop
for SERVICE in $SERVICE_LIST
do
    SERVICE_COUNT=$(expr $SERVICE_COUNT + 1)
    echo "..."
    echo "Application: $SERVICE"

    for Server in $(cat $INPUT_CSV | grep -iv "^#" | sed 's/^[[:space:]]*//g' | grep -i ",$SERVICE," | awk -F, '{ print $1 }' | sort -u)
    do
        UglyName=$(host $Server | grep -i address | awk -F\. '{ print $1 }' | head -1)
        [ "$UglyName" = "$Server" ] && UglyName=
        [[ -n $UglyName ]] && hpat="$Server|$UglyName" || hpat="$Server"

        # check to make sure the pattern doesn't match prod
        if egrep -iq "$hpat" <<< $PROD_HOSTS
        then 
          echo "!!! Host $Server appears to be prod - skipping !!!" 
          slack-comment -f AppScan -c team-ecom-mead -s "Prod host ($Server) in AppScan" -m "A possible production host ($Server/$UglyName) was picked up by AppScan [$PROD_HOSTS] "
          continue
        fi

        # special host list processing - for patch validation
        if [[ -n $HOST_LIST ]]
        then
          egrep -iq "$hpat" <<< $HOST_LIST || continue
          echo "/// Validate $Server ($UglyName)"
        fi

        # get cert info
        CERT_DATE=$(/bin/timeout -k 10s 5s openssl s_client -connect $Server.wsgc.com:443 -servername $Server.wsgc.com -showcerts </dev/null 2>&1| openssl x509 -noout -enddate 2>&1 | grep -i notafter | awk -F= '{ print $2 }')

        if [ -n "$CERT_DATE" ]
        then 
            CERT_DATE=$(date -d "$CERT_DATE" +'%Y-%m-%d')
            days=$(( ($(date --date="$CERT_DATE" '+%s') - $(date --date="$TODAY" '+%s')) / 86400))
            #echo "$Server cert expires: $CERT_DATE ($days)"
            if [ $days -lt $CERT_DAYS ] 
            then
                certificateNotification "Certificate for $Server expires in $days days ($CERT_DATE)"
            else
                TICKET=$(grep -i "$Server.*certificate" $TICKET_FILE | awk -F, '{ print $3 }' | tr '\n' ' ' | awk '{ print $1 }')
                [[ -n $TICKET ]] && ticketClose $TICKET "Certificate is up-to-date - $CERT_DATE - closing"
            fi
        fi
        [ -z "$KEYWORD" ] && echo "$Server,$CERT_DATE" >> $CERTS_FILE.new

        # find server in RunDeck - experimental
        RUNDECK_INFO=$(egrep -ihr "$Server" $TMP/rundeck 2>/dev/null)
        [[ -z $RUNDECK_INFO ]] && { RUNDECK_MISSING_COUNT=$(expr $RUNDECK_MISSING_COUNT + 1); echo "/// RunDeck missing ($Server)[$SERVICE]: $RUNDECK_MISSING_COUNT"; }
        #[[ -n RUNDECK_TAGS ]] && echo "RunDeck tags: $RUNDECK_TAGS"

        SERVICE_LIST=$(cat $INPUT_CSV | sed 's/^[[:space:]]*//g' | egrep -i "^$Server" | grep -i ",$SERVICE," | awk -F, '{ print $6 }')
        [ -z "$SERVICE_LIST" ] && echo "??? No services listed for $Server "
        #for ServiceName in $(cat $INPUT_CSV | sed 's/^[[:space:]]*//g' | egrep -i "^$Server" | grep -i ",$SERVICE," | awk -F, '{ print $6 }')
        for ServiceName in $SERVICE_LIST
        do
            DATE=$(date +'%Y-%m-%d %H:%M')
            FLAG=
            echo "---"

            TICKET=$(grep -i $Server $TICKET_FILE | awk -F, '{ print $3 }' | tr '\n' ' ')
            if [ -n "$TICKET" ] 
            then
                TICKET_FLAG="$TICKET_CREATED"
                for t in $TICKET
                do
                    TICKET_FLAG="$TICKET_FLAG <a href='$JIRA_URL/browse/$t'>$t</a>" 
                done
                TICKET_COUNT=$(expr $TICKET_COUNT + 1)
            else
                TICKET_FLAG=
            fi

            MonitorFlag=$(cat $INPUT_CSV | grep -i "^$Server" | sed 's/^[[:space:]]*//g' | grep -i ",$ServiceName," | awk -F, '{ print $2 }' | sort -u | head -1)
            Application=$(cat $INPUT_CSV | grep -i "^$Server" | sed 's/^[[:space:]]*//g' | grep -i ",$ServiceName," | awk -F, '{ print $3 }' | sort -u | head -1)
            Environment=$(cat $INPUT_CSV | grep -i "^$Server" | sed 's/^[[:space:]]*//g' | grep -i ",$ServiceName," | awk -F, '{ print $4 }' | sort -u | head -1)
            EndPoint=$(cat $INPUT_CSV | grep -i "^$Server" | sed 's/^[[:space:]]*//g' | grep -i ",$ServiceName," | awk -F, '{ print $5 }' | sort -u | head -1)
            RestartEnabled=$(cat $INPUT_CSV | grep -i "^$Server" | sed 's/^[[:space:]]*//g' | grep -i ",$ServiceName," | awk -F, '{ print $7 }' | tr "A-Z" "a-z" | sort -u | head -1)

            echo "  $Server"
            LOG_URL="<a href='http://$Server.wsgc.com:38667'>$Server</a>"

            #echo "  $SERVICE -> $Server|$MonitorFlag|$Application|$EndPoint|$ServiceName"
            EndPointURL="http://${Server}.wsgc.com${EndPoint}"

            if [ -n "$RUNDECK_INFO" ]
            then
                RUNDECK_FLAG=
                RUNDECK_NODE=$(echo "$RUNDECK_INFO" | awk -F 'node name=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g)
                RUNDECK_HOST=$(echo "$RUNDECK_INFO" | awk -F 'hostname=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g)
                RUNDECK_TAGS=$(echo "$RUNDECK_INFO" | awk -F 'tags=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g)
                RUNDECK_TAGS=$(echo "$RUNDECK_INFO" | awk -F 'tags=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | sed -es/",$"//g -es/guardrail_node//g)
                [[ $SERVICE = "rundeck" ]] && RUNDECK_TAGS=
                #echo "### RunDeck: $RUNDECK_NODE/$RUNDECK_HOST/$RUNDECK_TAGS"
            else
                RUNDECK_TAGS=
                RUNDECK_FLAG=$RUNDECK_MISSING
                echo "### - $Server not found in RunDeck"                
            fi 
         
            if [ "$MonitorFlag" = "d" ] 
            then
                    echo "@@@ $Server will be de-commissioned"
                    HTML "  <tr>"
                    HTML "      <td bgcolor='$STATUS_DECOM'>$SERVICE</td>"
                    HTML "      <td bgcolor='$STATUS_DECOM'><a href='' title='$RUNDECK_TAGS'>$Environment</a></td>"
                    HTML "      <td bgcolor='$STATUS_DECOM'>$LOG_URL $RUNDECK_FLAG<br>$UglyName</br></td>"
                    HTML "      <td bgcolor='$STATUS_DECOM'>$ServiceName</td>"
                    HTML "      <td bgcolor='$STATUS_DECOM'>$EndPointURL</td>"
                    HTML "  </tr>"
                    DECOM_COUNT=$(expr $DECOM_COUNT + 1)
                    continue
            fi

            # if the monitoring flag is negative, skip it
            if [ "$MonitorFlag" = "n" -o "$MonitorFlag" = "f" ]
            then
                if [ "$SHOW_UNMONITORED" = "true" ]
                then
                    echo ">>> Showing un-monitored $Server"
                    HTML "  <tr>"
                    HTML "      <td bgcolor='$STATUS_UM'>$SERVICE</td>"
                    HTML "      <td bgcolor='$STATUS_UM'><a href='' title='$RUNDECK_TAGS'>$Environment</a></td>"
                    HTML "      <td bgcolor='$STATUS_UM'>$LOG_URL $RUNDECK_FLAG<br>$UglyName</br></td>"
                    HTML "      <td bgcolor='$STATUS_UM'>$ServiceName</td>"
                    HTML "      <td bgcolor='$STATUS_UM'>$EndPointURL</td>"
                    HTML "  </tr>"
                    UNMONITORED_COUNT=$(expr $UNMONITORED_COUNT + 1)
                    continue
                else
                    echo "~~~ Monitor flag for $Server is '$MonitorFlag' - skipping"
                    break
                fi
            fi

            HTML "  <tr>"
            HTML "      <td>$SERVICE</td>"

            HTML "      <td>"
            [[ -n $RUNDECK_TAGS ]] && HTML "      <a href='' title='$RUNDECK_TAGS'>$Environment</a>" || HTML "      $Environment"
            HTML "      </td>"

            if ! testPing 
            then
                if ! testDNS 
                then
                    echo "Host not found in DNS"
                    updateNotification "Host not found in DNS"
                    BGCOLOR=$STATUS_DNS
                    DNS_FAIL_COUNT=$(expr $DNS_FAIL_COUNT + 1)
                else
                    echo "Host fails testPing"
                    #updateNotification "Host fails testPing"
                    BGCOLOR=$STATUS_PG 
                    PING_FAIL_COUNT=$(expr $PING_FAIL_COUNT + 1)
                fi
                HTML "      <td bgcolor='$BGCOLOR'>$LOG_URL $RUNDECK_FLAG<br>$UglyName</br></td>"
                HTML "      <td bgcolor='$STATUS_DN'>$ServiceName $TICKET_FLAG</td>"
                HTML "      <td bgcolor='$STATUS_DN'>$EndPointURL</td>"
                HTML "  </tr>"
                continue
            else
                HTML "      <td>$LOG_URL $RUNDECK_FLAG<br>$UglyName</br></td>"

                TICKET=$(grep "$Server,.*testPing" $TICKET_FILE | awk -F, '{ print $3 }') 
                [[ -n $TICKET ]] && ticketClose $TICKET "Host appears to be up, closing"

                TICKET=$(grep "$Server,.*Host not found" $TICKET_FILE | awk -F, '{ print $3 }') 
                [[ -n $TICKET ]] && ticketClose $TICKET "Host appears to be up, closing"
            fi

            if [ -z "$EndPoint" ]
            then
                HTML "      <td>&nbsp;</td>"
                HTML "      <td>&nbsp;</td>"
                HTML "  </tr>"
                echo "No EndPoint for service $ServiceName"
                continue
            fi

            serviceTest 
            status=$?

            if [ $status -ne 0 ] 
            then
                HTML "      <td bgcolor='$STATUS_DN'>$ServiceName $TICKET_FLAG</td>"
                HTML "      <td bgcolor='$STATUS_DN'><a href='$EndPointURL'>$EndPointURL $FLAG $RUNDECK_FLAG $http_status</a></td>"
                [ -z "$ServiceName" ] && ServiceName="application"
                updateNotification "$ServiceName not available"
            else
                HTML "      <td>$ServiceName</td>"
                HTML "      <td><a href='$EndPointURL'>$EndPointURL $RUNDECK_FLAG $FLAG</a></td>"
                updateProblems # this will clear the problems for this machine
            fi

            HTML "  </tr>"
        done
    done
done 

echo "***"

# close table tags
HTML "</table>"
#HTML "<p>Generated by <a href='https://ecombuild.wsgc.com/jenkins/job/app-scan-nonprd/'>app-scan-nonprd</a></p>"
echo "</table>" >> $MAILFILE

# get server count from input file
SERVER_COUNT=$(cat $INPUT_CSV | awk -F, '{ print $1 }' | egrep -iv "#" | sort -u | wc -l)

# get number of open jira tickets
JIRA_COUNT=$(cat $TICKET_FILE | egrep -v "^#" | wc -l)

# update the counts
sed -i $MAILFILE $OUTFILE \
    -es/@JIRA_COUNT@/$JIRA_COUNT/g \
    -es/@JIRA_OPENED@/$JIRA_OPENED/g \
    -es/@JIRA_CLOSED@/$JIRA_CLOSED/g \
    -es/@ISSUE_COUNT@/$ISSUE_COUNT/g \
    -es/@EMAIL_COUNT@/$EMAIL_COUNT/g \
    -es/@RESTART_INIT_COUNT@/$RESTART_INIT_COUNT/g \
    -es/@SERVICE_COUNT@/$SERVICE_COUNT/g \
    -es/@SERVER_COUNT@/$SERVER_COUNT/g \
    -es/@PING_FAIL_COUNT@/$PING_FAIL_COUNT/g \
    -es/@DNS_FAIL_COUNT@/$DNS_FAIL_COUNT/g \
    -es/@TICKET_COUNT@/$TICKET_COUNT/g \
    -es/@RESTART_FORBIDDEN_COUNT@/$RESTART_FORBIDDEN_COUNT/g \
    -es/@RESTART_CONFLICT_COUNT@/$RESTART_CONFLICT_COUNT/g \
    -es/@RUNDECK_MISSING_COUNT@/$RUNDECK_MISSING_COUNT/g \
    -es/@DECOM_COUNT@/$DECOM_COUNT/g \
    -es/@UNMONITORED_COUNT@/$UNMONITORED_COUNT/g 

# send out email
#[ $EMAIL_COUNT -gt 0 ] && sendmail -t $emailAddress -f $emailAddress < $MAILFILE

# trim history file
echo "*** Trim history to $HISTORY_DAYS days"
echo "Date, Services, Servers, Issues, Actions, Forbidden, Conflicts" > $HISTORY.new
for day in $(grep "^2.*," $HISTORY | awk -F, '{ print $1 }' | awk '{ print $1 }' | sort -u | tail -$HISTORY_DAYS)
do
    #echo $day
    grep "^$day" $HISTORY >> $HISTORY.new
done
mv $HISTORY.new $HISTORY

# only update confluence page if no args were passed in
if [[ -z $KEYWORD && -z $HOST_LIST ]] 
then
    echo "*** Update confluence $PAGENAME"
    sh $CCLIDIR/confluence.sh --space "$DOC_SPACE" --title "$PAGENAME" --action storepage --file $OUTFILE --noConvert --verbose || BailOut "Confluence update failed"

    # update history
    echo "*** Commit $(basename $HISTORY)"
    echo "$DATE, $SERVICE_COUNT, $SERVER_COUNT, $ISSUE_COUNT, $RESTART_INIT_COUNT, $RESTART_FORBIDDEN_COUNT, $RESTART_CONFLICT_COUNT" >> $HISTORY
    git pull --all --rebase --autostash >/dev/null 2>&1
    git add $HISTORY
    git commit -q -m "Update history" $HISTORY
    git push 
else
    echo "*** Not updating conluence ***"
fi

# scan the problems file to find systems for which we need to file tickets
echo "*** Scan problem file"
for svr in $(cat $PROBLEM_FILE | awk -F, '{ print $2 }' | sort -u | egrep -vi "Server")
do
    c=$(grep -iw "$svr" $PROBLEM_FILE | wc -l)
    if [ $c -gt $PROBLEM_THRESH ] 
    then
        PROJECT=$JIRA_TEAM
        grep -iq "$svr" $TICKET_FILE && continue

        problem=$(grep $svr $PROBLEM_FILE | awk -F, '{ print $3 }' | tail -1)

        # AEM-based tickets go to SCNS
        [[ $problem =~ cq ]] && PROJECT=SCNS
        [[ $problem =~ wcm ]] && PROJECT=SCNS
        [[ $problem =~ ecm ]] && PROJECT=SCNS
        [[ $svr =~ ecm ]] && PROJECT=SCNS
        [[ $svr =~ wcm ]] && PROJECT=SCNS
        [[ $svr =~ aem ]] && PROJECT=SCNS
        [[ $svr =~ aes ]] && PROJECT=SCNS
        [[ $svr =~ ecmpub ]] && PROJECT=SCNS
        [[ $svr =~ ecmauth ]] && PROJECT=SCNS

        echo "Creating $PROJECT ticket for $svr ($problem)"
        TICKET=$(jira-create -p $PROJECT -l $JIRA_LABEL -s "$JIRA_TITLE: $svr - $problem" -d "Condition '$problem' has persisted for more than $PROBLEM_THRESH scan cycles")
        echo "Created Jira $TICKET"
        JIRA_OPENED=$(expr $JIRA_OPENED + 1) 

        echo "$DATE,$Server,$TICKET,open,$problem" >> $JIRA_LOG

        # add log URL
        LOG_URL="http://$svr.wsgc.com:38667"
        jira-comment $TICKET "Logs: $LOG_URL"

        if [[ $problem =~ frontend ]]
        then 
          b=$(grep "$svr" $INPUT_CSV | awk -F, '{ print $3}' | sed -es/DP-//gi | tr '[:upper:]' '[:lower:]')
          e=$(grep "$svr" $INPUT_CSV | awk -F, '{ print $4}' | tr '[:upper:]' '[:lower:]')
#set -x
          jenkins-jnlp build -s checkenv \
            -p Brand=$b \
            -p Environment=$e \
            -p Ticket=$TICKET \
            -p Options=Check-Schema \
            -p Options=Deploy-War \
            -p Options=Deploy-Content \
            -p Options=Rebuild-Config \
            -p Options=Clear-Logs \
            -p Options=Host-Info \
            -p RunBy=AppScan > /dev/null 2>&1 &
            #-p Options=Force-Build \
{ set +x; } 2>/dev/null 
        fi

        # remove from problem file after we create the ticket
        cat $PROBLEM_FILE | egrep -viw "$svr" > $PROBLEM_FILE.new
        mv $PROBLEM_FILE.new $PROBLEM_FILE
        git add $PROBLEM_FILE
        git commit -q -m "Created $TICKET - clearing $svr" $PROBLEM_FILE
        git push -q

        # add to tickets file - experimental
        echo "$DATE,$svr,$TICKET,$problem" >> $TICKET_FILE
    fi
done

# trim restarts file
echo "*** Trim restarts to $RESTART_DAYS days"
echo "Date, Server, Service" > $RESTART_FILE.new
for day in $(grep "^2.*," $RESTART_FILE | awk -F, '{ print $1 }' | awk '{ print $1 }' | sort -u | tail -$RESTART_DAYS)
do
    #echo $day
    grep "^$day" $RESTART_FILE >> $RESTART_FILE.new
done
mv $RESTART_FILE.new $RESTART_FILE

# scan the restarts file to find systems for which we need to file tickets
echo "*** Scan restart file"
for svr in $(cat $RESTART_FILE | awk -F, '{ print $2 }' | sort -u | egrep -vi "Server")
do
    c=$(grep -iw "$svr" $RESTART_FILE | wc -l)
    if [ $c -gt $RESTART_THRESH ]
    then
        grep -iq "$svr" $TICKET_FILE && continue

#        echo "Creating $JIRA_TEAM ticket for $svr (excessive restarts: $c > $RESTART_THRESH in the past $RESTART_DAYS days)"
#        TICKET=$(jira-create -p $JIRA_TEAM -l $JIRA_LABEL -s "$JIRA_TITLE: $svr - $problem" -d "Service restarted more than $RESTART_THRESH times over $RESTART_DAYS days")
#        JIRA_OPENED=$(expr $JIRA_OPENED + 1) 
#        if [ -n "$TICKET" ]
#        then
#            echo "Created Jira $TICKET"
#
#            # add to tickets file
#            echo "$DATE,$svr,$TICKET,restarts" >> $TICKET_FILE
#
#            # remove from restart file
#            cat $RESTART_FILE | grep -iv "$svr" > $RESTART_FILE.new
#            mv $RESTART_FILE.new $RESTART_FILE
#        fi
    fi
done

# update cert expiration list
if [ -z "$KEYWORD" ]
then 
    echo "Server,Cert_Expiration" > $CERTS_FILE
    sort -k2 -k2.6 -k2.9 -h -t, $CERTS_FILE.new | uniq >> $CERTS_FILE
fi

#[[ -n $HOST_LIST ]] && { rm -rf $TMP; exit 0; }

# commit files
echo "*** Commit $(basename $PROBLEM_FILE) $(basename $TICKET_FILE) $(basename $RESTART_FILE) $(basename $CERTS_FILE)"
git pull --all --rebase --autostash
git add $PROBLEM_FILE $TICKET_FILE $RESTART_FILE $CERTS_FILE $JIRA_LOG
git commit -q -m "Update - $DATE" $PROBLEM_FILE $TICKET_FILE $RESTART_FILE $CERTS_FILE
[[ -z $KEYWORD && -z $HOST_LIST ]] && git commit -q -m "Update - $DATE" $CERTS_FILE
git push

rm -rf $TMP

exit 0
