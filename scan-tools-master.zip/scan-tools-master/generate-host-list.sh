#!/bin/sh
# crawls the rundeck resource repo and builds a CSV of hosts
TMP=/tmp/host-list
OUT=host-list-nonprd.csv
CSV=Ecom_Server_Inventory-v6.csv
MISSING=missing.txt
GROUPS_FILE=eComm-Host-List_NonProd.csv
GROUPS_FIELD=11
rm -f $OUT.new $MISSING
rm -rf $TMP
mkdir -p $TMP

git pull
REPO=git@github.wsgc.com:eCommerce-DevOps/toolchain-resource-model.git
git clone -q $REPO $TMP

XML_LIST=$(grep -ilr "node name=" $TMP | egrep -iv "prd|production|oracledb" | sort)
for XML in $XML_LIST
do
    for host in $(grep -i "hostname=" $XML | egrep -iv "prd|production|oracledb" | awk -F 'hostname=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | sort -u)
    do
        host=$(echo "$host" | awk -F\. '{ print $1 }')
echo
        # yes, this looks weird - this covers inconsistencies in how we name rundeck nodes
        alias=$(host $host | grep -i "alias" | awk '{ print $NF }' | awk -F\. '{ print $1 }')
        [ -z "$alias" ] && alias=$host

        node=$(egrep -iw "$host|$alias" $XML | head -1 | awk -F 'node name=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | sed -es/','/' '/g)
        alias=$(host $host | grep -i "alias" | awk '{ print $NF }' | awk -F\. '{ print $1 }')
        [ -z "$alias" ] && alias=$(host $node | grep -i alias | awk '{ print $NF }' | awk -F\. '{ print $1 }')
        [ -z "$alias" ] && alias=$host
        node=$(egrep -iw "$host|$alias" $XML | head -1 | awk -F 'node name=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | sed -es/','/' '/g)

        xcsv=$(egrep -iw "$node|$host|$alias" $CSV | awk -F, '{ print $1 }')
        if [ -z "$xcsv" ]
        then
           echo "$host ($node) missing from CSV" 
           echo "$host,$node" >> $MISSING; 
           echo "$host,,,,,," >> $CSV
        fi

        #GROUPS_FIELD
echo "$XML" | egrep -iq "omsd2|pricing" && set -x || set +x
set -x
        awk -F, 'NF!=14{ORS=(ORS!=" "?" ":RS)}{$1=$1}1' OFS=, $GROUPS_FILE | egrep -iw "$host|$node|$alias" | awk -F, '{ print $11 }' #| head -1 | sed -es/\"//g)
exit

        fwgroup=$(awk -F, 'NF!=14{ORS=(ORS!=" "?" ":RS)}{$1=$1}1' OFS=, $GROUPS_FILE  | egrep -iw "$host|$node|$alias" | awk -F, '{ print $11 }' | head -1 | sed -es/\"//g)
exit
        echo "FW Group: $fwgroup"

        #echo "node: $host $XML"
        group=$(basename $(dirname $XML))
#echo "$XML" | egrep -iq registry && set -x || set +x
        tags=$(grep -iw "$host" $XML | head -1 | awk -F 'tags=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | sed -es/','/' '/g)
        echo "tags before> $tags"
        # tag massage
        tags=$(echo "$tags" | sed -es"/guardrail_node//"g)
        tags=$(echo "$tags" | sed -es"/\bint[1-9]\b//g" -es"/\bint//g")
        tags=$(echo "$tags" | sed -es"/\bdev[1-9]\b//g" -es"/\bdev//g")
        tags=$(echo "$tags" | sed -es"/\brgs[1-9]\b//g" -es"/\brgs//g")

        tags=$(echo "$tags" | sed -es"/stg1//"g)
        tags=$(echo "$tags" | sed -es"/el6//"g)
        tags=$(echo "$tags" | sed -es"/ecmq//"g)
        tags=$(echo "$tags" | sed -es"/apmagents//"g)
        tags=$(echo "$tags" | sed -es"/\brk[1-9]\b//g" -es"/\bsac[1-9]//g")
        tags=$(echo "$tags" | sed -es"/\bintdev[0-9]\b//g" -es"/\bintdev[0-9][0-9]\b//g")
        tags=$(echo "$tags" | sed -es"/\bperf[1-9]\b//g" -es"/\bperf//g")
        tags=$(echo "$tags" | sed -es"/\buat[1-9]\b//g" -es"/\buat//g")
        tags=$(echo "$tags" | sed -es"/\bqa[1-9][0-9]\b//g" -es"/\bqa[1-9]//g" -es"/\bqa//"g)
        tags=$(echo "$tags" | sed -es"/\bmg\b//g" -es"/\bpb\b//g" -es"/\bpk\b//g" -es"/\bpt\b//g" -es"/\bwe\b//g" -es"/\bws\b//g")

        echo "tags after> $tags"

        # assign a group based on tag keywords
        echo "$tags" | grep -iq "c3" && group="c3"
        echo "$tags" | grep -iq "prsfc" && group="salesforce"
        echo "$tags" | grep -iq "aos" && group="aos"
        echo "$tags" | grep -iq "profile" && group="profile"
        echo "$tags" | grep -iq "aem" && group="cms"
        echo "$tags" | grep -iq "wcm" && group="cms"
        echo "$tags" | grep -iq "ecm" && group="cms"
        echo "$tags" | grep -iq "contentprocessor" && group="cms"
        echo "$tags" | grep -iq "buildsystem" && group="cms"
        echo "$tags" | grep -iq "bgb" && group="cms"
        echo "$tags" | grep -iq "mdm" && group="mdm"
        echo "$tags" | grep -iq "rewards" && group="rewards"
        echo "$tags" | grep -iq "homefront" && group="homefront"
        echo "$tags" | grep -iq "jenkins" && group="jenkins"
        echo "$tags" | grep -iq "xcprf" && group="dp"
        echo "$tags" | grep -iq "xcadm" && group="dp"
        echo "$tags" | grep -iq "ecmprv" && group="dp"
        echo "$tags" | grep -iq "frontend" && group="dp"
        echo "$tags" | grep -iq "loyalty" && group="loyalty"
        echo "$tags" | grep -iq "registry" && group="registry"
        echo "$tags" | grep -iq "pricing" && group="pricing"
        echo "$tags" | grep -iq "vertex" && group="pricing"
        echo "$tags" | grep -iq "promoadm" && group="pricing"
        echo "$tags" | grep -iq "singleuse" && group="pricing"
        echo "$tags" | grep -iq "omsd.*publisher" && group="pricing"
        echo "$tags" | grep -iq "pradm" && group="pricing"
        echo "$tags" | grep -iq "oauth" && group="oauth"
        echo "$tags" | grep -iq "oss-" && group="oss"
        echo "$tags" | grep -iq "sccint" && group="scc"
        echo "$tags" | grep -iq "sccext" && group="scc"
        echo "$tags" | grep -iq "sccext" && group="scc"
        echo "$tags" | grep -iq "sandbox" && group="sandbox"
        echo "$tags" | grep -iq "favorites" && group="favorites"
        echo "$tags" | grep -iq "dse" && group="cassandra"
        echo "$tags" | grep -iq "cassandra" && group="cassandra"
        echo "$tags" | grep -iq "cre" && group="cre"
        echo "$tags" | grep -iq "cpcr" && group="cre"

        echo "$host" | grep -iq "aerodb" && group="cre"
        echo "$host" | grep -iq "locker-dev-rk2v" && group="cms"
        echo "$host" | grep -iq "xcprf" && group="dp"
        echo "$host" | grep -iq "credbdev" && group="cre"
        echo "$host" | grep -iq "endi" && group="endeca"
        echo "$host" | grep -iq "endmdex" && group="endeca"

        echo "$group" | grep -iq "registry" && group="registry"

        # only add aliases to the table that are different from the host or node name
        [ "$alias" = "$node" -o "$alias" = "$host" ] && alias=
        i=$(host $host | grep -i address | tail -1 | awk '{ print $NF }')

#echo "alias: $alias node: $node"
        echo "$group,$fwgroup,$host,$node,$alias,$i,$tags"
        echo "$group,$fwgroup,$host,$node,$alias,$i,$tags" >> $OUT.new
    done

done

echo "Group, FW Group, HostName, NodeName, DNSName, IP, Tags" > $OUT
sort $OUT.new >> $OUT
rm -f $OUT.new

git pull
git add $OUT $0 $CSV
git commit -m "Update" $OUT $0 $CSV
git push

exit 0

